def find_smallest_unrepresentable(arr):
    arr.sort()
    res = 1
    for num in arr:
        if num > res:
            break
        res += num
    return res
