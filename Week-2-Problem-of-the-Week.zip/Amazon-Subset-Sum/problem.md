# Smallest Positive Integer Not Representable by Subset Sum

**Company**: Amazon

## Problem:
Given an array of positive integers, find the smallest positive integer that cannot be represented as sum of elements of any subset of the given set.

### Example:
Input:
```
arr = [1, 2, 3, 10]
```
Output:
```
7
```

### Constraints:
- 1 ≤ N ≤ 10^6
- 1 ≤ A[i] ≤ 10^9
