# Week 2 – Problem of the Week (21st July 2025)

This week's challenge includes problems from top tech companies.

## Problems:
1. **Longest Common Subsequence in 3 Strings** – YouTube
2. **Smallest Positive Integer Not Representable by Subset Sum** – Amazon
3. **Find All Valid Step Words From a Given Word and Dictionary** – Pivotal

Each folder contains:
- Full problem description
- Code solution
- Notes or alternative approaches

Feel free to improve solutions or try them in different languages!
