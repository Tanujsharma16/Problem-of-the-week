# Longest Common Subsequence in 3 Strings

**Company**: YouTube

## Problem:
Given three strings A, B, and C, find the length of their longest common subsequence.

### Example:
Input:
```
A = "abc"
B = "abc"
C = "abc"
```
Output:
```
3
```

### Constraints:
- 1 ≤ len(A), len(B), len(C) ≤ 100
