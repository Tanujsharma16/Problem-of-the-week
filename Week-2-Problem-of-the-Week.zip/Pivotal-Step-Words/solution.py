from collections import Counter

def find_step_words(source, dictionary):
    source_count = Counter(source)
    result = []

    for word in dictionary:
        if len(word) != len(source) + 1:
            continue
        word_count = Counter(word)
        diff = word_count - source_count
        if sum(diff.values()) == 1:
            result.append(word)
    return result
