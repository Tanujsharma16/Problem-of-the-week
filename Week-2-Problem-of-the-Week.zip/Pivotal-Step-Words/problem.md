# Find All Valid Step Words

**Company**: Pivotal

## Problem:
Given a source word and a dictionary, find all valid "step words". A step word is made by adding exactly one letter to the source word and rearranging the result to form another valid word in the dictionary.

### Example:
Input:
```
source = "APPLE"
dictionary = ["APPEAL", "PALE", "APPLE", "LAPPED"]
```
Output:
```
["APPEAL", "LAPPED"]
```

### Constraints:
- 1 ≤ len(source) ≤ 100
- Dictionary size ≤ 1000
